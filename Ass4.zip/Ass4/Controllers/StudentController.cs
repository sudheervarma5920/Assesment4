﻿using CollegeApp.Entities;
using Microsoft.AspNetCore.Mvc;

namespace CollegeApp.Controllers
{
    public class StudentController : Controller
    {
        private readonly CollegeAppContext collegeAppContext;
        public StudentController()
        {
            collegeAppContext = new CollegeAppContext();
        }
        public IActionResult Index()
        {
            var res = collegeAppContext.Students;
            return View(res);
        }
        [HttpGet]
        public IActionResult Create()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Create(Student student)
        {
            if (ModelState.IsValid)
            {
                collegeAppContext.Students.Add(student);
                collegeAppContext.SaveChanges();
                return View(student);
            }
            else
            {
                return View();
            }
        }
        public IActionResult GetStudentById(int id)
        {
            var res = collegeAppContext.Students.FirstOrDefault(a => a.StudentId == id);
            return View(res);
        }
        [HttpGet]
        public IActionResult Delete(int id)
        {
            var res=collegeAppContext.Students.FirstOrDefault(a=>a.StudentId == id);
            return View(res);
        }
        [HttpPost]
        public IActionResult Delete(Student student)
        {
            collegeAppContext.Students.Remove(student);
            collegeAppContext.SaveChanges();
            return View(student);
        }
    }
}