﻿using Microsoft.AspNetCore.Mvc;
using CollegeApp.Entities;
namespace CollegeApp.Controllers
{
    public class CompanyController : Controller
    {
        private readonly CollegeAppContext collegeAppContext;
        public CompanyController()
        {
            collegeAppContext = new CollegeAppContext();    
        }
        public IActionResult Index()
        {
            var res = collegeAppContext.Companies;
            return View(res);
        }
        [HttpGet]
        public IActionResult Create()
        {
            return View();  
        }
        [HttpPost]
        public IActionResult Create(Company company)
        {
            if (ModelState.IsValid)
            {
                collegeAppContext.Companies.Add(company);
                collegeAppContext.SaveChanges();
                return View(company);
            }
            else
            {
                return View();
            }
        }
    }
}
